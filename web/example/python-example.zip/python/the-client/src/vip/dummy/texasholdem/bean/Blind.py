

class Blind():
    def __init__(self,playerName,amount):
        self.playerName = playerName
        self.amount = amount