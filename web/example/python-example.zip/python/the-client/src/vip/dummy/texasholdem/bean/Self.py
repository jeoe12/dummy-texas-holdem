class Self():
    def __init__(self, playerName, chips, folded, allIn, isSurvive,
                 cards, roundBet, bet, minBet):
        self.playerName = playerName
        self.chips = chips
        self.folded = folded
        self.allIn = allIn
        self.isSurvive = isSurvive
        self.cards = cards
        self.roundBet = roundBet
        self.bet = bet
        self.minBet = minBet
