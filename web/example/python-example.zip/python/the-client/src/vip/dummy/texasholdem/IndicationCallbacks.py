class IndicationCallbacks():
    def onNewPeer(newPeerIndication):
        pass

    def onNewRound(newRoundIndication):
        pass

    def onStartReload(startReloadIndication):
        pass

    def onDeal(dealIndication):
        pass

    def onAction(actionIndication):
        pass

    def onBet(betIndication):
        pass

    def onShowAction(showActionIndication):
        pass

    def onRoundEnd(roundEndIndication):
        pass

    def onGameOver(gameOverIndication):
        pass
