class BetData():
    def __init__(self, tableNumber, myself, game):
        self.tableNumber = tableNumber
        self.self = myself
        self.game = game
