class StartReloadData():
    def __init__(self, tableNumber, players):
        self.tableNumber = tableNumber
        self.players = players
