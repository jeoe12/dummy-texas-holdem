class GameOverData():
    def __init__(self, table, players, winners):
        self.table = table
        self.players = players
        self.winners = winners
