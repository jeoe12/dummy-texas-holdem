class DealData():
    def __init__(self, table, players):
        self.table = table
        self.players = players
