class ShowActionData():
    def __init__(self, action, table, players):
        self.action = action
        self.table = table
        self.players = players
