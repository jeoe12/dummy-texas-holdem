from Data import Data
class ReloadData(Data):
    def __init__(self):
       print("empty")