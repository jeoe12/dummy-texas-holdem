

class Hand():
    def __init__(self, cards, rank,message):
        self.cards = cards
        self.rank = rank
        self.message = message

