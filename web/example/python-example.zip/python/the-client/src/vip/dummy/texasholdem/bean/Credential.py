

class Credential():
    def __init__(self,phoneNumber,password):
        self.phoneNumber = phoneNumber
        self.password = password